const { user, profile, followerFollowing } = require("../../models");

exports.addFeed = async (req, res) => {
  try {
    const feed = await feed.create({
      userId: req.user.id,
      image: req.file.filename,
      caption: req.body.caption,
    });

    res.status(200).send({
      status: "success",
      data: {
        feed: {
          ...feed,
          user: req.user,
        },
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "failed",
      message: "Server error...",
    });
  }
};
